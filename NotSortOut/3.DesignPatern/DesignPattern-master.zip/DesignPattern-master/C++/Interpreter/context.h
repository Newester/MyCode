#ifndef _CONTEXT_H_ 
#define _CONTEXT_H_

class Context { 
public:
 	Context();
	~Context();
};
#endif //~_CONTEXT_H_