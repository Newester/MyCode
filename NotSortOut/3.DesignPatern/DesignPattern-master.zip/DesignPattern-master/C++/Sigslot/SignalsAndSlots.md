## Signals and Slots

​	Sigslot 是Sarah Thompson 设计实现的C++ 事件处理的框架,    这套框架非常轻量级,  全部代码只有一个sigslot.h 文件,   其设计也非常出色,  最大限度的将事件和处理机制解耦, 并且保证了线程安全。





#### 参考资料

+ [sigslot - C++ Signal/Slot Library](http://sigslot.sourceforge.net/)
+ [Sigslot - WebRTC中的事件处理机制](http://blog.csdn.net/volvet/article/details/52269876)